#!/bin/bash

#4HTEMPO Plots
python createACFPlots.py avgautocorrF0 4HTEMPO
python createACFPlots.py avgnumberCorr 4HTEMPO
python createACFPlots.py avgHBCorr 4HTEMPO
python createACFPlots.py avgOrientCorr_P1 4HTEMPO
python createACFPlots.py avgOrientCorr_P2 4HTEMPO

