#!/bin/bash

#Water Plots
python createACFPlots.py avgautocorrF0 Water
python createACFPlots.py avgnumberCorr Water
python createACFPlots.py avgHBCorr Water
python createACFPlots.py avgOrientCorr_P1 Water
python createACFPlots.py avgOrientCorr_P2 Water

#4HTEMPO Plots
python createACFPlots.py avgautocorrF0 4HTEMPO
python createACFPlots.py avgnumberCorr 4HTEMPO
python createACFPlots.py avgHBCorr 4HTEMPO
python createACFPlots.py avgOrientCorr_P1 4HTEMPO
python createACFPlots.py avgOrientCorr_P2 4HTEMPO

#PEO12 Plots
python createACFPlots.py avgautocorrF0 PEO12
python createACFPlots.py avgnumberCorr PEO12
python createACFPlots.py avgHBCorr PEO12
python createACFPlots.py avgOrientCorr_P1 PEO12
python createACFPlots.py avgOrientCorr_P2 PEO12
